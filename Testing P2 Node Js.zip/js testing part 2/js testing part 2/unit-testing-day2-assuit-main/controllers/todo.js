
var todosModel = require('../models/todo')

const GetAllTodos = async (_req, res) => {
  try {
    var todos = await todosModel.find().populate('userId', "name")
    res.status(200).json({ data: todos });
  } catch (err) {
    res.status(500).json({ message: "Couldn't find todos please try again" })
  }
}


const SaveTodo = async (req, res) => {
  var Title = req.body.title
  try {

    var newTodo = await todosModel.create({ title: title, userId: req.id })
    res.status(201).json({ data: newTodo })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
}



const GetTodoById = async (req, res) => {
  var { id } = req.params

  try {
    var todo = await todosModel.findOne({ _id: id })
    if (todo) {
      res.status(200).json({ data: todo })
    } else {
      res.status(404).json({ message: "todo not found" })
    }
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
}

// for lab
const updateTitleTodoById = async (req, res) => {
  var { title } = req.body
  var { id } = req.params

  try {
    if (id && title) {
      var UpdatedTodo = await todosModel.findOneAndUpdate({ _id: id }, { title: title }, { new: true })
      res.status(200).json({ data: UpdatedTodo })
    }
    else res.status(400).json({ message: " You must provide title and id to edit todo" })
  } catch (e) {
    res.status(400).json({ message: e.message })
  }
}


const GetUserTodos = async (req, res) => {

  try {

    var todos = await todosModel.find({ userId: req.id })
    todos.length > 0 && res.status(200).json({ data: todos })
    todos.length == 0 && res.status(200).json({ message: "Couldn't find any todos for " + req.id })
  } catch (e) {
    res.status(400).json({ message: e.message })
  }
}


const DeleteAllTodos = async (_req, res) => {
  try {
    await todosModel.deleteMany()
    res.status(200).json({ message: "todos have been deleted successfully" })
  } catch (e) {
    res.status(400).json({ message: e.message })
  }
}



module.exports = { GetAllTodos, SaveTodo, GetTodoById, updateTitleTodoById, DeleteAllTodos, GetUserTodos }