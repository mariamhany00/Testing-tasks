
var userModel = require('../models/user')

const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')


const GetAllUser =async(req, res) => {
    let users = await userModel.find()
    res.status(200).json({ data: users })
}

const SaveUser=async (req, res) => {
    var user = req.body
    try {
        var newUser = await userModel.create(user)
        res.status(201).json({ data: newUser })
    } catch (error) {
        res.status(500).json({ message: error.message })
    }

}
const login =  async function (req, res) {  

    var { email, password } = req.body
    if (!email || !password) {
        return res.status(400).json({ message: 'please Enter Email and Password' })
    }

    try {

        var User = await userModel.findOne({ email })
        if (!User) {
            return res.status(401).json({ message: 'Invalid email or password' })
        }
        var isValid = await bcrypt.compare(password, User.password)

        if (!isValid) {
            return res.status(401).json({ message: 'Invalid email or password' })
        }

     var token = jwt.sign({ id: User._id, name: User.name }, process.env.SECRET)


      res.status(200).json({ token, status: "Success" })
    } catch (err) {
        res.status(400).json({ message: err.message })
    }


}

const GetUserById=async(req, res) => {       
    let User = await userModel.findOne({ _id:req.params.id })
    res.status(200).json({ data: User })
}




//lab
const GetUserByName= async (req, res) => {
    try {
        var {name} = req.query
        var User = await userModel.findOne({ name })
        if (User) res.status(200).json({data:User})
        else {
            res.status(200).json({ message: "There is no User with  name: " + name })
        }
    } catch (e) {
        res.status(400).json({ message: e.message })
    }
}
   
const DeleteAllUsers=async (_req, res) => {
    try {
        await userModel.deleteMany()
        res.status(200).json({ message: "users have been deleted successfully" })
    } catch (e) {
        res.status(400).json({ message: e.message })
    }
}

module.exports = { SaveUser, GetAllUser, GetUserByName,DeleteAllUsers,GetUserById,login }