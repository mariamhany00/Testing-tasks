const express = require('express')
const {  SaveUser, DeleteAllUsers, GetUserByName, GetAllUser, GetUserById, login } = require('../controllers/user')
var Userrouter = express.Router()




//get all uses
//  /user
Userrouter.get("/", GetAllUser)

// /user/signup
Userrouter.post('/signup',SaveUser)


Userrouter.post('/login', login)


//lab
Userrouter.get("/search", GetUserByName)

Userrouter.delete("/", GeleteAllUsers)



//get user by id
Userrouter.get("/:id", GetUserById)

module.exports = Userrouter