
const express=require('express')
var router=express.Router()
var {GetAllTodos,SaveTodo,GetTodoById, updateTitleTodoById, GetUserTodos, DeleteAllTodos}=require('../controllers/todo')
var auth=require('../middlewares/auth')


//get all todos
router.route("/").get(GetAllTodos).post(auth,SaveTodo).delete(auth,DeleteAllTodos)


//lab
//update todo by id
router.patch("/:id",auth, updateTitleTodoById)

//get all todos for user=> id
router.get("/user",auth, GetUserTodos)



//get todo by id
router.get("/:id",auth,GetTodoById)
module.exports=router