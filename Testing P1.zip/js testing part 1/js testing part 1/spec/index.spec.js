const User = require("../lab2");


describe('test user obj', () => {
  let user;

  beforeEach(() => {
    user = new User('mariam', 'zoozoo');
  })
  it(" Adds a product to the cart array.", () => {
    const Products = { Name: 'Blouse', Price: 300 };
    user.addToCart(Products);
    expect(user.cart).toContain(Products);
  });

  it("testing calculateTotalCartPrice logic", () => {
    const products = [
      { Name: "coat", Price: 200 },
      { Name: "jacket", Price: 240 },
    ];
    products.forEach((item) => user.addToCart(item));
    const Total = products.reduce((Accumletor, prduct) => Accumletor + prduct.Price, 0);
    expect(user.calculateTotalCartPrice()).toBe(Total);
  });
  it('These are test cases for Checkout func', () => {
    const paymentModel = {
      goToVerifyPage: jasmine.createSpy(),
      returnBack: jasmine.createSpy(),
      isVerify: jasmine.createSpy().and.returnValue(true),
    };
    expect(user.checkout(paymentModel)).toBe(true);
    expect(paymentModel.goToVerifyPage()).toHaveBeenCalled;
    expect(paymentModel.returnBack()).toHaveBeenCalled;
    expect(paymentModel.isVerify()).toHaveBeenCalled;
  })
})